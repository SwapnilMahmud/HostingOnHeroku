
<?php $__env->startSection('page_title','Manage_product'); ?>
<?php $__env->startSection('product_select','active'); ?>
<?php $__env->startSection('container'); ?>
<?php if($id>0): ?>
<?php echo e($image_required=""); ?>

<?php else: ?>
<?php echo e($image_required="required"); ?>

<?php endif; ?>
<?php echo e(session('message')); ?> 
<h3>Manage Product</h3>
 <a href="<?php echo e(url('admin/product')); ?>">
    <button type="button" class="btn btn-success">Back</button>
</a></br>
<!-- MAIN CONTENT-->
<div class="row m-t-30">
   <div class="col-md-12">
            <form action="<?php echo e(route('product.manage_product_process')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
      <div class="row">
         <div class="col-lg-12">
            <div class="card">
                  <div class="card-header"><b>Provide Product Information.</b></div>
               <div class="card-body">                       
                        <div class="form-group">
                           <label for="name" class="control-label mb-1">product Name</label>
                           <input  id="name" value="<?php echo e($name); ?>" name="name" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                           <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="alert alert-danger" role="alert">
                           <?php echo e($message); ?>

                           </div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                           <label for="slug" class="control-label mb-1">product Slug</label>
                           <input id="slug" value="<?php echo e($slug); ?>" name="slug" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                           <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="alert alert-danger" role="alert">
                           <?php echo e($message); ?>

                           </div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                            
                        </div>
                        <div class="form-group">
                           <label for="image" class="control-label mb-1">product image</label>
                           <input  id="image" value="<?php echo e($image); ?>" name="image" type="file" class="form-control" aria-required="true" aria-invalid="false" <?php echo e($image_required); ?>>
                           <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <div class="alert alert-danger" role="alert">
                           <?php echo e($message); ?>

                           </div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                           <div class="row">
                              <div class="col-md-4">
                                 <label for="category_id" class="control-label mb-1">Category</label>
                                 <select  id="category_id"  name="category_id" type="text" class="form-control" required>
                                 <option value="">select categories</option>
                                 <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option selected  value="<?php echo e($list->id); ?>"><?php echo e($list->category_name); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>
                              </div>
                              <div class="col-md-4">
                                 <label for="brand" class="control-label mb-1">Brand</label>
                                 <input  id="brand" value="<?php echo e($brand); ?>" name="brand" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                              </div>
                              <div class="col-md-4">
                                 <label for="model" class="control-label mb-1">Model</label>
                                 <input  id="model" value="<?php echo e($model); ?>" name="model" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                              </div>
                           </div>
                        </div>
                        <div class="form-group">
                           <label for="short_desc" class="control-label mb-1">Short desc..</label>
                           <textarea  id="short_desc"  name="short_desc" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($short_desc); ?></textarea>
                        </div>
                        <div class="form-group">
                           <label for="desc" class="control-label mb-1">desc</label>
                           <textarea  id="desc"  name="desc" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($desc); ?></textarea>
                        </div>
                        <div class="form-group">
                           <label for="keywords" class="control-label mb-1">keywords</label>
                           <textarea  id="keywords"  name="keywords" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($keywords); ?></textarea>
                        </div>
                        <div class="form-group">
                           <label for="technical_specification" class="control-label mb-1">Technical Specification</label>
                           <textarea  id="technical_specification"  name="technical_specification" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($technical_specification); ?></textarea>
                        </div>
                        <div class="form-group">
                           <label for="uses" class="control-label mb-1">uses</label>
                           <textarea  id="uses"  name="uses" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($uses); ?></textarea>
                        </div>
                        <div class="form-group">
                           <label for="warranty" class="control-label mb-1">warranty</label>
                           <textarea  id="warranty"  name="warranty" type="text" class="form-control" aria-required="true" aria-invalid="false" required><?php echo e($warranty); ?></textarea>
                        </div>    
                        
                </div>
                          <div class="col-lg-12"  id="product_attr_box">
                             
                                   <?php 
                                   $loop_count_num=1;
                                   ?>                          
                                   <?php $__currentLoopData = $productAttrArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php
                                   $loop_count_prev= $loop_count_num;
                                   $pAArr=(array)$val; //type casting for object convert in array                                                   
                                   ?>
                           <div class="card" id="product_attr_<?php echo e($loop_count_num++); ?>">
                                <div class="card-header"><b>Provide Attribute.</b></div>
                                   <div class="card-body">  
                                       <div class= "form-group">
                                             <div class="row">
                                                   <div class="col-md-2">
                                                      <label for="sku" class="control-label mb-1">SKU</label>
                                                      <input  id="sku"  value="<?php echo e($pAArr['sku']); ?>"  name="sku[]" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                                    </div>
                                                   <div class="col-md-2">
                                                       <label for="mrp" class="control-label mb-1">MRP</label>
                                                       <input  id="mrp" value="<?php echo e($pAArr['mrp']); ?>"  name="mrp[]" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <label for="price" class="control-label mb-1">PRICE</label>
                                                        <input  id="price"  value="<?php echo e($pAArr['price']); ?>"  name="price[]" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                                    </div>
                                                    <div class="col-md-3">
                                                         <label for="size_id" class="control-label mb-1">Size</label>
                                                          <select  id="size_id"  name="size_id[]" type="text" class="form-control" required>
                                                <option value="">select Size</option>
                                                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <?php if($pAArr['size_id']==$list->id): ?>
                                                      <option value="<?php echo e($list->id); ?>" selected ><?php echo e($list->size); ?></option>
                                                   <?php else: ?>
                                                      <option value="<?php echo e($list->id); ?>"><?php echo e($list->size); ?></option>
                                                   <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                             </select>
                                                    </div>
                                                    <div class="col-md-3">
                                                          <label for="color_id" class="control-label mb-1">Color</label>
                                                          <select  id="color_id"  name="color_id[]" type="text" class="form-control" required>
                                                <option value="">Color</option>
                                                <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($pAArr['color_id']==$list->id): ?>
                                                      <option  value="<?php echo e($list->id); ?>" selected><?php echo e($list->color); ?></option>
                                                <?php else: ?>
                                                      <option  value="<?php echo e($list->id); ?>"><?php echo e($list->color); ?></option>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             </select>
                                                    </div>
                                                    <div class="col-md-2">
                                                            <label for="qty" class="control-label mb-1">QTY</label>
                                                            <input  id="qty"  value="<?php echo e($pAArr['qty']); ?>"  name="qty[]" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                                    </div>
                                                    <div class="col-md-4">
                                                             <label for="attr_image" class="control-label mb-1">IMAGE</label>
                                                            <input  id="attr_image"  name="attr_image[]" type="file" class="form-control" aria-required="true" aria-invalid="false" required>
                                                    </div>
                                                    <?php if($loop_count_num==2): ?>
                                                    <div class="col-md-1">
                                                             <label for="" class="control-label mb-1">&nbsp;&nbsp;&nbsp;</label>
                                                             <button type="button" class="btn btn-success btn-lg" onclick="add_more()">
                                                             <i class="fa fa-plus"></i> &nbsp; Add</button>
                                                    </div>
                                                     <?php else: ?>
                                                    <div class="col-md-1">
                                                              <label for="" class="control-label mb-1">&nbsp;&nbsp;&nbsp;</label>
                                                               <button type="button" class="btn btn-danger btn-lg" onclick="remove_more('<?php echo e($loop_count_prev); ?>')">
                                                               <i class="fa fa-minus"></i> &nbsp; Remove</button>
                                                     </div>
                                                     <?php endif; ?>
                                                </div>
                                       </div>   </div>   </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   </div>
                                    <div class="form-group">                                
                                      <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">Submit</div>
                                       <input  value="<?php echo e($id); ?>" name="id" type="hidden" >                               
                                    </div>
                            </div>
                        </div>   
         </div>
                       
                        
      </div>
      </form>                  
   </div>   
                        <script>
                           var loop_count=1;
                           function add_more(){
                           loop_count++;
                           var html='<div class="card" id="product_attr_'+loop_count+'"><div class="card-body"<div class="form-group"><div class="row">';
                           html+='<div class="col-md-2"><label for="category_id" class="control-label mb-1">SKU</label><input id="sku"  name="sku[]" type="text" class="form-control" aria-required="true" aria-invalid="false" ></div>';                        
                           html+='<div class="col-md-2"><label for="mrp" class="control-label mb-1">MRP</label><input  id="mrp"  name="mrp[]" type="text" class="form-control" aria-required="true" aria-invalid="false" > </div>';
                           html+='<div class="col-md-2"><label for="price" class="control-label mb-1">PRICE</label><input  id="price"  name="price[]" type="text" class="form-control" aria-required="true" aria-invalid="false" ></div>';
                           var size_id_html=jQuery('#size_id').html();
                           html+='<div class="col-md-3"> <label for="size_id" class="control-label mb-1">Size</label> <select  id="size_id"  name="size_id[]" type="text" class="form-control" >'+size_id_html+'</select></div>';
                           var color_id_html=jQuery('#color_id').html();
                           html+=' <div class="col-md-3"><label for="color_id" class="control-label mb-1">Color</label><select  id="color_id"  name="color_id[]" type="text" class="form-control" > <option value="">'+color_id_html+'</select> </div>';
                           html+='<div class="col-md-2"><label for="qty" class="control-label mb-1">QTY</label> <input  id="qty"  name="qty[]" type="text" class="form-control" aria-required="true" aria-invalid="false" ></div>';
                           html+='<div class="col-md-4"><label for="attr_image" class="control-label mb-1">IMAGE</label><input  id="attr_image"  name="attr_image[]" type="file" class="form-control" aria-required="true" aria-invalid="false" ></div>';
                           html+='<div class="col-md-1"><label for="" class="control-label mb-1">&nbsp;&nbsp;&nbsp;</label><button type="button" class="btn btn-danger btn-lg" onclick=remove_more("'+loop_count+'")><i class="fa fa-minus"></i> &nbsp; Remove</button></div>';
                           html+='</div></div></div></div>';
                           jQuery('#product_attr_box').append(html);
                           }
                           function remove_more(loop_count){
                              jQuery('#product_attr_'+loop_count).remove();
                           }
                        </script>
</div>
<div class="row">
   <div class="col-md-12">
      <div class="copyright">
      <p>Copyright © 2018 Colorlib. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
      </div>
   </div>
</div>     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\Laravel-E-commerce\e-commerce\resources\views\admin\manage_product.blade.php ENDPATH**/ ?>