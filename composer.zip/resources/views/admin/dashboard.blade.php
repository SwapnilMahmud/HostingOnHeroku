@extends('admin/layout')
@section('page_title','Dashboard')
@section('dashboard_select','active')
@section('container')
<div class="row">                           
   <h3>Dashboard</h3>
</div>
@endsection