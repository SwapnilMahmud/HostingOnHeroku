<?php

return[
    'site_name'=>'E-commerce' 
]
?>